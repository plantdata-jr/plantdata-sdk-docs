const graph = new PdSDKZcGraph({
    showAllSchemaOptions: true,
    kgName: 'default_graph_m3dyxz4c9ryvpa5m',
    selector: document.getElementById('chart'),
    ajaxSettings: {
        baseUrl: 'https://kgms.plantdata.ai/plantdata-sdk/api/sdk/',
        headers: {
            APK: '3a33e491b6ff4374bcdd3d74b432668f',
            Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJoaWVrbiIsImV4cCI6MTU0N' +
                'DQyNjAyNCwiaWF0IjoxNTQzMjE2NDI0LCJ1c2VySWQiOiJhNWU5Mzl0cW5tMXF6ZWlrIn0.Yh2pRmgR6n4SMyvO_' +
                'NZC9Sn7I5MZGfOzSDrUNOYTaU8'
        }
    },
    netChartSettings: {
        rightPanel: {
            active: true,
            mode: 'fixed'
        }
    },
    infobox: {
        settings: {
            active: true
        }
    }
})
graph.load()
